import { BaseResolver } from './resolve.js';
import { SpecMajorVersion } from './oas-types.js';
import { type Config } from './config/index.js';
import type { Plugin, ResolvedConfig } from './config/types.js';
import type { NormalizedNodeType, NodeType } from './types/index.js';
import type { NormalizedProblem } from './walk.js';
import type { Document, ResolvedRefMap } from './resolve.js';
import type { CollectFn } from './utils.js';
export declare enum OasVersion {
    Version2 = "oas2",
    Version3_0 = "oas3_0",
    Version3_1 = "oas3_1"
}
export type CoreBundleOptions = {
    externalRefResolver?: BaseResolver;
    config: Config;
    dereference?: boolean;
    base?: string | null;
    removeUnusedComponents?: boolean;
    keepUrlRefs?: boolean;
};
export declare function collectConfigPlugins(document: Document, resolvedRefMap: ResolvedRefMap, rootConfigDir: string): (string | Plugin)[];
export declare function bundleConfig(document: Document, resolvedRefMap: ResolvedRefMap, plugins: Plugin[]): ResolvedConfig;
export declare function bundle(opts: {
    ref?: string;
    doc?: Document;
    collectSpecData?: CollectFn;
} & CoreBundleOptions): Promise<BundleResult>;
export declare function bundleFromString(opts: {
    source: string;
    absoluteRef?: string;
} & CoreBundleOptions): Promise<BundleResult>;
export type BundleResult = {
    bundle: Document;
    problems: NormalizedProblem[];
    fileDependencies: Set<string>;
    rootType: NormalizedNodeType;
    refTypes?: Map<string, NormalizedNodeType>;
    visitorsData: Record<string, Record<string, unknown>>;
};
export declare function bundleDocument(opts: {
    document: Document;
    config: Config;
    customTypes?: Record<string, NodeType>;
    externalRefResolver: BaseResolver;
    dereference?: boolean;
    removeUnusedComponents?: boolean;
    keepUrlRefs?: boolean;
}): Promise<BundleResult>;
export declare function mapTypeToComponent(typeName: string, version: SpecMajorVersion): "links" | "schemas" | "parameters" | "responses" | "examples" | "requestBodies" | "headers" | "securitySchemes" | "callbacks" | "definitions" | null;
//# sourceMappingURL=bundle.d.ts.map