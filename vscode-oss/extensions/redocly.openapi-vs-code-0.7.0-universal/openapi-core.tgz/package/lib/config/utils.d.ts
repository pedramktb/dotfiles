import type { ImportedPlugin, RawResolveConfig, ResolveConfig, ResolvedGovernanceConfig, Plugin, PluginCreator } from './types.js';
import type { Oas3RuleSet, Oas2RuleSet, Async3RuleSet, Async2RuleSet, Arazzo1RuleSet, Overlay1RuleSet } from '../oas-types.js';
export declare function parsePresetName(presetName: string): {
    pluginId: string;
    configName: string;
};
export declare function prefixRules<T extends Oas3RuleSet | Oas2RuleSet | Async3RuleSet | Async2RuleSet | Arazzo1RuleSet | Overlay1RuleSet>(rules: T, prefix: string): T;
export declare function mergeExtends(rulesConfList: ResolvedGovernanceConfig[]): Required<ResolvedGovernanceConfig>;
export declare function getResolveConfig(resolve?: RawResolveConfig): ResolveConfig;
export declare class ConfigValidationError extends Error {
}
export declare function deepCloneMapWithJSON<K, V>(originalMap: Map<K, V>): Map<K, V>;
export declare function isDeprecatedPluginFormat(plugin: ImportedPlugin | undefined): plugin is Plugin;
export declare function isCommonJsPlugin(plugin: ImportedPlugin | undefined): plugin is PluginCreator;
//# sourceMappingURL=utils.d.ts.map