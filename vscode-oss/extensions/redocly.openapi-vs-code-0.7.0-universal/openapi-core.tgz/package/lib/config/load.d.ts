import { BaseResolver, type Document, type ResolvedRefMap } from '../resolve.js';
import { Config } from './config.js';
import { type RawUniversalConfig } from './types.js';
export type RawConfigProcessor = (params: {
    document: Document;
    resolvedRefMap: ResolvedRefMap;
    config: Config;
    parsed: Document['parsed'];
}) => void | Promise<void>;
export declare function loadConfig(options?: {
    configPath?: string;
    customExtends?: string[];
    /** Deprecated */
    processRawConfig?: RawConfigProcessor;
    externalRefResolver?: BaseResolver;
}): Promise<Config>;
export declare const CONFIG_FILE_NAMES: string[];
export declare function findConfig(dir?: string): string | undefined;
type CreateConfigOptions = {
    configPath?: string;
    externalRefResolver?: BaseResolver;
    resolvedRefMap?: ResolvedRefMap;
};
export declare function createConfig(config?: string | RawUniversalConfig, { configPath, externalRefResolver }?: CreateConfigOptions): Promise<Config>;
export {};
//# sourceMappingURL=load.d.ts.map