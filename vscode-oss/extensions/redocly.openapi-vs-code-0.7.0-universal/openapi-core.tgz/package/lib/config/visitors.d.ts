import type { OasRef } from '../typings/openapi.js';
import type { Plugin } from './types.js';
import type { ResolveResult, UserContext } from '../walk.js';
export declare function makePluginsCollectorVisitor(plugins: (string | Plugin)[], rootConfigDir: string): import("../visitors.js").NormalizedOasVisitors<{
    ref: {};
    ConfigGovernance: {
        leave(node: any, ctx: UserContext): void;
    };
    ConfigApisProperties: {
        leave(node: any, ctx: UserContext): void;
    };
    'rootRedoclyConfigSchema.scorecard.levels_items': {
        leave(node: any, ctx: UserContext): void;
    };
    ConfigRoot: {
        leave(node: any, ctx: UserContext): void;
    };
}>;
export declare function makeConfigBundlerVisitor(plugins: Plugin[]): import("../visitors.js").NormalizedOasVisitors<{
    ref: {
        leave(node: OasRef, ctx: UserContext, resolved: ResolveResult<any>): void;
    };
    ConfigGovernance: {
        leave(node: any, ctx: UserContext): void;
    };
    ConfigApisProperties: {
        leave(node: any, ctx: UserContext): void;
    };
    'rootRedoclyConfigSchema.scorecard.levels_items': {
        leave(node: any, ctx: UserContext): void;
    };
    ConfigRoot: {
        leave(node: any, ctx: UserContext): void;
    };
}>;
//# sourceMappingURL=visitors.d.ts.map