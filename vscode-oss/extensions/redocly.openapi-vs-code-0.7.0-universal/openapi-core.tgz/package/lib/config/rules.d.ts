import type { Arazzo1RuleSet, Async2RuleSet, Async3RuleSet, Oas2RuleSet, Oas3RuleSet, Overlay1RuleSet, SpecVersion } from '../oas-types.js';
import type { Config } from './config.js';
import type { ProblemSeverity } from '../walk.js';
type InitializedRule = {
    severity: ProblemSeverity;
    ruleId: string;
    visitor: any;
};
export declare function initRules(rules: (Oas3RuleSet | Oas2RuleSet | Async2RuleSet | Async3RuleSet | Arazzo1RuleSet | Overlay1RuleSet)[], config: Config, type: 'rules' | 'preprocessors' | 'decorators', oasVersion: SpecVersion): InitializedRule[];
export {};
//# sourceMappingURL=rules.d.ts.map