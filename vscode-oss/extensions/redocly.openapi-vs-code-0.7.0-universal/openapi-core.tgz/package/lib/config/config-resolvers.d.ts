import { BaseResolver } from '../resolve.js';
import type { Plugin, RawUniversalConfig, ResolvedConfig, RawGovernanceConfig } from './types.js';
import type { Document, ResolvedRefMap } from '../resolve.js';
export type ConfigOptions = {
    rawConfigDocument?: Document<RawUniversalConfig>;
    configPath?: string;
    externalRefResolver?: BaseResolver;
    customExtends?: string[];
};
export declare function resolveConfig({ rawConfigDocument, configPath, externalRefResolver, customExtends, }: ConfigOptions): Promise<{
    resolvedConfig: ResolvedConfig;
    resolvedRefMap: ResolvedRefMap;
    plugins: Plugin[];
}>;
export declare const preResolvePluginPath: (plugin: string | Plugin, base: string, rootConfigDir: string) => string | Plugin;
export declare function resolvePlugins(plugins: (string | Plugin)[], configDir: string): Promise<Plugin[]>;
export declare function resolvePreset(presetName: string, plugins: Plugin[]): RawGovernanceConfig;
//# sourceMappingURL=config-resolvers.d.ts.map