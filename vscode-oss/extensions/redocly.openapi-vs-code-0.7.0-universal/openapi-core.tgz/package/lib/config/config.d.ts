import { SpecVersion, SpecMajorVersion } from '../oas-types.js';
import { type Document, type ResolvedRefMap } from '../resolve.js';
import type { NormalizedProblem } from '../walk.js';
import type { Oas2RuleSet, Oas3RuleSet, Async3RuleSet, Arazzo1RuleSet, Overlay1RuleSet } from '../oas-types.js';
import type { NodeType } from '../types/index.js';
import type { DecoratorConfig, Plugin, PreprocessorConfig, ResolveConfig, ResolvedConfig, RuleConfig, RuleSettings } from './types.js';
export declare const IGNORE_FILE = ".redocly.lint-ignore.yaml";
export declare class Config {
    resolvedConfig: ResolvedConfig;
    configPath?: string;
    document?: Document;
    resolvedRefMap?: ResolvedRefMap;
    resolve: ResolveConfig;
    _alias?: string;
    plugins: Plugin[];
    ignore: Record<string, Record<string, Set<string>>>;
    doNotResolveExamples: boolean;
    rules: Record<SpecVersion, Record<string, RuleConfig>>;
    preprocessors: Record<SpecVersion, Record<string, PreprocessorConfig>>;
    decorators: Record<SpecVersion, Record<string, DecoratorConfig>>;
    private _usedRules;
    private _usedVersions;
    constructor(resolvedConfig: ResolvedConfig, opts?: {
        configPath?: string;
        document?: Document;
        resolvedRefMap?: ResolvedRefMap;
        alias?: string;
        plugins?: Plugin[];
    });
    forAlias(alias?: string): Config;
    resolveIgnore(ignoreFile?: string): void;
    saveIgnore(): void;
    addIgnore(problem: NormalizedProblem): void;
    addProblemToIgnore(problem: NormalizedProblem): NormalizedProblem;
    extendTypes(types: Record<string, NodeType>, version: SpecVersion): Record<string, NodeType>;
    getRuleSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getPreprocessorSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getDecoratorSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getUnusedRules(): {
        rules: string[];
        preprocessors: string[];
        decorators: string[];
    };
    getRulesForSpecVersion(version: SpecMajorVersion): Oas3RuleSet[] | Oas2RuleSet[] | Async3RuleSet[] | Arazzo1RuleSet[] | Overlay1RuleSet[];
    skipRules(rules?: string[]): void;
    skipPreprocessors(preprocessors?: string[]): void;
    skipDecorators(decorators?: string[]): void;
}
//# sourceMappingURL=config.d.ts.map