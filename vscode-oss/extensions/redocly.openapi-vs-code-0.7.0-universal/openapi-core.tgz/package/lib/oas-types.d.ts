import type { BuiltInAsync2RuleId, BuiltInAsync3RuleId, BuiltInArazzo1RuleId, BuiltInOAS2RuleId, BuiltInOAS3RuleId, BuiltInOverlay1RuleId } from './types/redocly-yaml.js';
import type { Oas3Rule, Oas3Preprocessor, Oas2Rule, Oas2Preprocessor, Async2Preprocessor, Async2Rule, Async3Preprocessor, Async3Rule, Arazzo1Preprocessor, Arazzo1Rule, Overlay1Preprocessor, Overlay1Rule } from './visitors.js';
export declare enum SpecVersion {
    OAS2 = "oas2",
    OAS3_0 = "oas3_0",
    OAS3_1 = "oas3_1",
    Async2 = "async2",
    Async3 = "async3",
    Arazzo1 = "arazzo1",
    Overlay1 = "overlay1"
}
export declare enum SpecMajorVersion {
    OAS2 = "oas2",
    OAS3 = "oas3",
    Async2 = "async2",
    Async3 = "async3",
    Arazzo1 = "arazzo1",
    Overlay1 = "overlay1"
}
export type RuleMap<Key extends string, RuleConfig, T> = Record<T extends 'built-in' ? Key : string, RuleConfig>;
export type Oas3RuleSet<T = undefined> = RuleMap<BuiltInOAS3RuleId | 'struct' | 'assertions', Oas3Rule, T>;
export type Oas2RuleSet<T = undefined> = RuleMap<BuiltInOAS2RuleId | 'struct' | 'assertions', Oas2Rule, T>;
export type Async2RuleSet<T = undefined> = RuleMap<BuiltInAsync2RuleId | 'struct' | 'assertions', Async2Rule, T>;
export type Async3RuleSet<T = undefined> = RuleMap<BuiltInAsync3RuleId | 'struct' | 'assertions', Async3Rule, T>;
export type Arazzo1RuleSet<T = undefined> = RuleMap<BuiltInArazzo1RuleId | 'struct' | 'assertions', Arazzo1Rule, T>;
export type Overlay1RuleSet<T = undefined> = RuleMap<BuiltInOverlay1RuleId | 'struct' | 'assertions', Overlay1Rule, T>;
export type Oas3PreprocessorsSet = Record<string, Oas3Preprocessor>;
export type Oas2PreprocessorsSet = Record<string, Oas2Preprocessor>;
export type Async2PreprocessorsSet = Record<string, Async2Preprocessor>;
export type Async3PreprocessorsSet = Record<string, Async3Preprocessor>;
export type Arazzo1PreprocessorsSet = Record<string, Arazzo1Preprocessor>;
export type Overlay1PreprocessorsSet = Record<string, Overlay1Preprocessor>;
export type Oas3DecoratorsSet = Record<string, Oas3Preprocessor>;
export type Oas2DecoratorsSet = Record<string, Oas2Preprocessor>;
export type Async2DecoratorsSet = Record<string, Async2Preprocessor>;
export type Async3DecoratorsSet = Record<string, Async3Preprocessor>;
export type Arazzo1DecoratorsSet = Record<string, Arazzo1Preprocessor>;
export type Overlay1DecoratorsSet = Record<string, Overlay1Preprocessor>;
export declare function detectSpec(root: unknown): SpecVersion;
export declare function getMajorSpecVersion(version: SpecVersion): SpecMajorVersion;
export declare function getTypes(spec: SpecVersion): Record<string, import("./index.js").NodeType> | {
    readonly Root: import("./index.js").NodeType;
    readonly Tag: import("./index.js").NodeType;
    readonly TagList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: import("./index.js").NodeType;
    readonly ExternalDocs: import("./index.js").NodeType;
    readonly Example: import("./index.js").NodeType;
    readonly ExamplesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: import("./index.js").NodeType;
    readonly SecurityRequirement: import("./index.js").NodeType;
    readonly SecurityRequirementList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Info: import("./index.js").NodeType;
    readonly Contact: import("./index.js").NodeType;
    readonly License: import("./index.js").NodeType;
    readonly Logo: import("./index.js").NodeType;
    readonly Paths: import("./index.js").NodeType;
    readonly PathItem: import("./index.js").NodeType;
    readonly Parameter: import("./index.js").NodeType;
    readonly ParameterItems: import("./index.js").NodeType;
    readonly ParameterList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Operation: import("./index.js").NodeType;
    readonly Examples: import("./index.js").NodeType;
    readonly Header: import("./index.js").NodeType;
    readonly Responses: import("./index.js").NodeType;
    readonly Response: import("./index.js").NodeType;
    readonly Schema: import("./index.js").NodeType;
    readonly Xml: import("./index.js").NodeType;
    readonly SchemaProperties: import("./index.js").NodeType;
    readonly NamedSchemas: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityScheme: import("./index.js").NodeType;
    readonly XCodeSample: import("./index.js").NodeType;
    readonly XCodeSampleList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly XServerList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly XServer: import("./index.js").NodeType;
} | {
    readonly Root: import("./index.js").NodeType;
    readonly Tag: import("./index.js").NodeType;
    readonly TagList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: import("./index.js").NodeType;
    readonly ExternalDocs: import("./index.js").NodeType;
    readonly Server: import("./index.js").NodeType;
    readonly ServerList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: import("./index.js").NodeType;
    readonly ServerVariablesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityRequirement: import("./index.js").NodeType;
    readonly SecurityRequirementList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Info: import("./index.js").NodeType;
    readonly Contact: import("./index.js").NodeType;
    readonly License: import("./index.js").NodeType;
    readonly Paths: import("./index.js").NodeType;
    readonly PathItem: import("./index.js").NodeType;
    readonly Parameter: import("./index.js").NodeType;
    readonly ParameterList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Operation: import("./index.js").NodeType;
    readonly Callback: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly CallbacksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly RequestBody: import("./index.js").NodeType;
    readonly MediaTypesMap: import("./index.js").NodeType;
    readonly MediaType: import("./index.js").NodeType;
    readonly Example: import("./index.js").NodeType;
    readonly ExamplesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Encoding: import("./index.js").NodeType;
    readonly EncodingMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: import("./index.js").NodeType;
    readonly Header: import("./index.js").NodeType;
    readonly HeadersMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Responses: import("./index.js").NodeType;
    readonly Response: import("./index.js").NodeType;
    readonly Link: import("./index.js").NodeType;
    readonly Logo: import("./index.js").NodeType;
    readonly Schema: import("./index.js").NodeType;
    readonly Xml: import("./index.js").NodeType;
    readonly SchemaProperties: import("./index.js").NodeType;
    readonly DiscriminatorMapping: import("./index.js").NodeType;
    readonly Discriminator: import("./index.js").NodeType;
    readonly Components: import("./index.js").NodeType;
    readonly LinksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedRequestBodies: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedHeaders: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedCallbacks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly ImplicitFlow: import("./index.js").NodeType;
    readonly PasswordFlow: import("./index.js").NodeType;
    readonly ClientCredentials: import("./index.js").NodeType;
    readonly AuthorizationCode: import("./index.js").NodeType;
    readonly OAuth2Flows: import("./index.js").NodeType;
    readonly SecurityScheme: import("./index.js").NodeType;
    readonly XCodeSample: import("./index.js").NodeType;
    readonly XCodeSampleList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly XUsePkce: import("./index.js").NodeType;
    readonly WebhooksMap: import("./index.js").NodeType;
} | {
    readonly Info: import("./index.js").NodeType;
    readonly Root: import("./index.js").NodeType;
    readonly Schema: import("./index.js").NodeType;
    readonly SchemaProperties: import("./index.js").NodeType;
    readonly PatternProperties: import("./index.js").NodeType;
    readonly License: import("./index.js").NodeType;
    readonly Components: import("./index.js").NodeType;
    readonly NamedPathItems: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityScheme: import("./index.js").NodeType;
    readonly Operation: import("./index.js").NodeType;
    readonly DependentRequired: import("./index.js").NodeType;
    readonly Tag: import("./index.js").NodeType;
    readonly TagList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: import("./index.js").NodeType;
    readonly ExternalDocs: import("./index.js").NodeType;
    readonly Server: import("./index.js").NodeType;
    readonly ServerList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: import("./index.js").NodeType;
    readonly ServerVariablesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityRequirement: import("./index.js").NodeType;
    readonly SecurityRequirementList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Contact: import("./index.js").NodeType;
    readonly Paths: import("./index.js").NodeType;
    readonly PathItem: import("./index.js").NodeType;
    readonly Parameter: import("./index.js").NodeType;
    readonly ParameterList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Callback: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly CallbacksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly RequestBody: import("./index.js").NodeType;
    readonly MediaTypesMap: import("./index.js").NodeType;
    readonly MediaType: import("./index.js").NodeType;
    readonly Example: import("./index.js").NodeType;
    readonly ExamplesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Encoding: import("./index.js").NodeType;
    readonly EncodingMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: import("./index.js").NodeType;
    readonly Header: import("./index.js").NodeType;
    readonly HeadersMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Responses: import("./index.js").NodeType;
    readonly Response: import("./index.js").NodeType;
    readonly Link: import("./index.js").NodeType;
    readonly Logo: import("./index.js").NodeType;
    readonly Xml: import("./index.js").NodeType;
    readonly DiscriminatorMapping: import("./index.js").NodeType;
    readonly Discriminator: import("./index.js").NodeType;
    readonly LinksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedRequestBodies: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedHeaders: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedCallbacks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly ImplicitFlow: import("./index.js").NodeType;
    readonly PasswordFlow: import("./index.js").NodeType;
    readonly ClientCredentials: import("./index.js").NodeType;
    readonly AuthorizationCode: import("./index.js").NodeType;
    readonly OAuth2Flows: import("./index.js").NodeType;
    readonly XCodeSample: import("./index.js").NodeType;
    readonly XCodeSampleList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly XUsePkce: import("./index.js").NodeType;
    readonly WebhooksMap: import("./index.js").NodeType;
};
//# sourceMappingURL=oas-types.d.ts.map