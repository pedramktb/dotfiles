export declare const name = "Validate with 50 top-level rules";
export declare const count = 10;
export declare function setupAsync(): Promise<void>;
export declare function measureAsync(): Promise<import("../../walk.js").NormalizedProblem[]>;
//# sourceMappingURL=lint-with-many-rules.bench.d.ts.map