export declare const name = "Validate with no rules";
export declare const count = 10;
export declare function setupAsync(): Promise<void>;
export declare function measureAsync(): Promise<import("../../walk.js").NormalizedProblem[]>;
//# sourceMappingURL=lint-with-no-rules.bench.d.ts.map