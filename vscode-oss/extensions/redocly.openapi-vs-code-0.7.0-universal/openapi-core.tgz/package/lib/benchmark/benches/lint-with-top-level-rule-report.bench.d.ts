export declare const name = "Validate with single top-level rule and report";
export declare const count = 10;
export declare function setupAsync(): Promise<void>;
export declare function measureAsync(): Promise<import("../../walk.js").NormalizedProblem[]>;
//# sourceMappingURL=lint-with-top-level-rule-report.bench.d.ts.map