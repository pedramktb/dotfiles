export declare const name = "Resolve with no external refs";
export declare const count = 10;
export declare function measureAsync(): Promise<import("../../resolve.js").ResolvedRefMap>;
//# sourceMappingURL=resolve-with-no-external.bench.d.ts.map