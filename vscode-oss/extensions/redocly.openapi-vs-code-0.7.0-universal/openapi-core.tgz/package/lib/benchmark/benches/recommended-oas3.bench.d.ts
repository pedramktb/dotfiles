export declare const name = "Validate with recommended rules";
export declare const count = 10;
export declare function measureAsync(): Promise<import("../../walk.js").NormalizedProblem[]>;
//# sourceMappingURL=recommended-oas3.bench.d.ts.map