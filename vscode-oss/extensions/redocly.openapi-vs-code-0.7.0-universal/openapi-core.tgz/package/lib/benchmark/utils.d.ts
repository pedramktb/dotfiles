import { StyleguideConfig } from '../config/index.js';
import type { Document } from '../resolve.js';
import type { Oas3RuleSet } from '../oas-types.js';
import type { Plugin } from '../config/types.js';
export declare function parseYamlToDocument(body: string, absoluteRef?: string): Document;
export declare function makeConfigForRuleset(rules: Oas3RuleSet, plugin?: Partial<Plugin>): Promise<StyleguideConfig>;
//# sourceMappingURL=utils.d.ts.map