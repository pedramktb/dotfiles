import type { JSONSchema } from 'json-schema-to-ts';
import type { NodeType } from './index.js';
import type { Config } from '../config/index.js';
declare const builtInOAS2Rules: readonly ["info-contact", "operation-operationId", "tag-description", "tags-alphabetical", "info-license-url", "info-license-strict", "info-license", "no-ambiguous-paths", "no-enum-type-mismatch", "no-http-verbs-in-paths", "no-identical-paths", "no-invalid-parameter-examples", "no-invalid-schema-examples", "no-path-trailing-slash", "operation-2xx-response", "operation-4xx-response", "operation-description", "operation-operationId-unique", "operation-operationId-url-safe", "operation-parameters-unique", "operation-singular-tag", "operation-summary", "operation-tag-defined", "parameter-description", "path-declaration-must-exist", "path-excludes-patterns", "path-http-verbs-order", "path-not-include-query", "path-params-defined", "path-parameters-defined", "path-segment-plural", "paths-kebab-case", "required-string-property-missing-min-length", "response-contains-header", "scalar-property-missing-example", "security-defined", "spec-strict-refs", "no-unresolved-refs", "no-required-schema-properties-undefined", "no-schema-type-mismatch", "boolean-parameter-prefixes", "request-mime-type", "response-contains-property", "response-mime-type"];
export type BuiltInOAS2RuleId = typeof builtInOAS2Rules[number];
declare const builtInOAS3Rules: readonly ["info-contact", "operation-operationId", "tag-description", "tags-alphabetical", "info-license-url", "info-license-strict", "info-license", "no-ambiguous-paths", "no-enum-type-mismatch", "no-http-verbs-in-paths", "no-identical-paths", "no-invalid-parameter-examples", "no-invalid-schema-examples", "no-path-trailing-slash", "operation-2xx-response", "operation-4xx-response", "operation-description", "operation-operationId-unique", "operation-operationId-url-safe", "operation-parameters-unique", "operation-singular-tag", "operation-summary", "operation-tag-defined", "parameter-description", "path-declaration-must-exist", "path-excludes-patterns", "path-http-verbs-order", "path-not-include-query", "path-params-defined", "path-parameters-defined", "path-segment-plural", "paths-kebab-case", "required-string-property-missing-min-length", "response-contains-header", "scalar-property-missing-example", "security-defined", "spec-strict-refs", "no-unresolved-refs", "no-required-schema-properties-undefined", "no-schema-type-mismatch", "boolean-parameter-prefixes", "component-name-unique", "no-empty-servers", "no-example-value-and-externalValue", "no-invalid-media-type-examples", "no-server-example.com", "no-server-trailing-slash", "no-server-variables-empty-enum", "no-undefined-server-variable", "no-unused-components", "operation-4xx-problem-details-rfc7807", "request-mime-type", "response-contains-property", "response-mime-type", "spec-components-invalid-map-name", "array-parameter-serialization"];
export type BuiltInOAS3RuleId = typeof builtInOAS3Rules[number];
declare const builtInAsync2Rules: readonly ["info-contact", "info-license-strict", "operation-operationId", "tag-description", "tags-alphabetical", "channels-kebab-case", "no-channel-trailing-slash"];
declare const builtInAsync3Rules: readonly ["info-contact", "info-license-strict", "operation-operationId", "tag-description", "tags-alphabetical", "channels-kebab-case", "no-channel-trailing-slash"];
export type BuiltInAsync2RuleId = typeof builtInAsync2Rules[number];
export type BuiltInAsync3RuleId = typeof builtInAsync3Rules[number];
declare const builtInArazzo1Rules: readonly ["sourceDescription-type", "workflowId-unique", "stepId-unique", "sourceDescription-name-unique", "sourceDescriptions-not-empty", "workflow-dependsOn", "parameters-unique", "step-onSuccess-unique", "step-onFailure-unique", "respect-supported-versions", "requestBody-replacements-unique", "no-criteria-xpath", "criteria-unique", "no-x-security-scheme-name-without-openapi", "x-security-scheme-required-values", "no-x-security-scheme-name-in-workflow"];
export type BuiltInArazzo1RuleId = typeof builtInArazzo1Rules[number];
declare const builtInOverlay1Rules: readonly ["info-contact"];
export type BuiltInOverlay1RuleId = typeof builtInOverlay1Rules[number];
export declare function createConfigTypes(extraSchemas: JSONSchema, config?: Config): {
    'rootRedoclyConfigSchema.scorecard.levels_items': NodeType;
    ConfigRoot: NodeType;
    ConfigApisProperties: NodeType;
    AssertionDefinitionSubject: NodeType;
};
export declare const ConfigTypes: Record<string, NodeType>;
export declare const NormalizedConfigTypes: Record<string, import("./index.js").NormalizedNodeType>;
export {};
//# sourceMappingURL=redocly-yaml.d.ts.map