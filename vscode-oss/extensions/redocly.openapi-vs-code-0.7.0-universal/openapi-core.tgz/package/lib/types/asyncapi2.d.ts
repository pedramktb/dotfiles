import type { NodeType } from './index.js';
export declare const Tag: NodeType;
export declare const ExternalDocs: NodeType;
export declare const ServerMap: NodeType;
export declare const ServerVariable: NodeType;
export declare const Contact: NodeType;
export declare const License: NodeType;
export declare const CorrelationId: NodeType;
export declare const MessageExample: NodeType;
export declare const Schema: NodeType;
export declare const SchemaProperties: NodeType;
export declare const DiscriminatorMapping: NodeType;
export declare const Discriminator: NodeType;
export declare const SecuritySchemeFlows: NodeType;
export declare const Dependencies: NodeType;
export declare const AsyncApi2Bindings: Record<string, NodeType>;
export declare const AsyncApi2Types: Record<string, NodeType>;
//# sourceMappingURL=asyncapi2.d.ts.map