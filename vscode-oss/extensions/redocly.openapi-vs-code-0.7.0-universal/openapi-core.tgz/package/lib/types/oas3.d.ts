import { type NodeType } from './index.js';
export declare const ExternalDocs: NodeType;
export declare const Xml: NodeType;
export declare const DiscriminatorMapping: NodeType;
export declare const Discriminator: NodeType;
export declare const ImplicitFlow: NodeType;
export declare const PasswordFlow: NodeType;
export declare const ClientCredentials: NodeType;
export declare const AuthorizationCode: NodeType;
export declare const OAuth2Flows: NodeType;
export declare const Oas3Types: {
    readonly Root: NodeType;
    readonly Tag: NodeType;
    readonly TagList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: NodeType;
    readonly ExternalDocs: NodeType;
    readonly Server: NodeType;
    readonly ServerList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: NodeType;
    readonly ServerVariablesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityRequirement: NodeType;
    readonly SecurityRequirementList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Info: NodeType;
    readonly Contact: NodeType;
    readonly License: NodeType;
    readonly Paths: NodeType;
    readonly PathItem: NodeType;
    readonly Parameter: NodeType;
    readonly ParameterList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly Operation: NodeType;
    readonly Callback: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly CallbacksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly RequestBody: NodeType;
    readonly MediaTypesMap: NodeType;
    readonly MediaType: NodeType;
    readonly Example: NodeType;
    readonly ExamplesMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Encoding: NodeType;
    readonly EncodingMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: NodeType;
    readonly Header: NodeType;
    readonly HeadersMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Responses: NodeType;
    readonly Response: NodeType;
    readonly Link: NodeType;
    readonly Logo: NodeType;
    readonly Schema: NodeType;
    readonly Xml: NodeType;
    readonly SchemaProperties: NodeType;
    readonly DiscriminatorMapping: NodeType;
    readonly Discriminator: NodeType;
    readonly Components: NodeType;
    readonly LinksMap: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedRequestBodies: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedHeaders: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedCallbacks: {
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly ImplicitFlow: NodeType;
    readonly PasswordFlow: NodeType;
    readonly ClientCredentials: NodeType;
    readonly AuthorizationCode: NodeType;
    readonly OAuth2Flows: NodeType;
    readonly SecurityScheme: NodeType;
    readonly XCodeSample: NodeType;
    readonly XCodeSampleList: {
        name: string;
        properties: {};
        items: string;
    };
    readonly XUsePkce: NodeType;
    readonly WebhooksMap: NodeType;
};
//# sourceMappingURL=oas3.d.ts.map