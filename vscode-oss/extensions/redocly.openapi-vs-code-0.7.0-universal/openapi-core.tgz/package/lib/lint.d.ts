import { BaseResolver } from './resolve.js';
import { type Config } from './config/index.js';
import type { Document } from './resolve.js';
import type { ProblemSeverity } from './walk.js';
import type { NodeType } from './types/index.js';
import type { CollectFn } from './utils.js';
export declare function lint(opts: {
    ref: string;
    config: Config;
    externalRefResolver?: BaseResolver;
    collectSpecData?: CollectFn;
}): Promise<import("./walk.js").NormalizedProblem[]>;
export declare function lintFromString(opts: {
    source: string;
    absoluteRef?: string;
    config: Config;
    externalRefResolver?: BaseResolver;
}): Promise<import("./walk.js").NormalizedProblem[]>;
export declare function lintDocument(opts: {
    document: Document;
    config: Config;
    customTypes?: Record<string, NodeType>;
    externalRefResolver: BaseResolver;
}): Promise<import("./walk.js").NormalizedProblem[]>;
export declare function lintConfig(opts: {
    config: Config;
    severity?: ProblemSeverity;
    externalRefResolver?: BaseResolver;
    externalConfigTypes?: Record<string, NodeType>;
}): Promise<import("./walk.js").NormalizedProblem[]>;
//# sourceMappingURL=lint.d.ts.map