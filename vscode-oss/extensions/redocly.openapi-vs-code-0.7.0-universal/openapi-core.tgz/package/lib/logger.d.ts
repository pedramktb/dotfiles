import * as colorette from 'colorette';
export declare const colorOptions: {
    enabled: boolean;
};
export declare const colorize: typeof colorette;
declare class Logger {
    info(str: string): boolean | void;
    warn(str: string): boolean | void;
    error(str: string): boolean | void;
    output(str: string): boolean | void;
}
export declare const logger: Logger;
export {};
//# sourceMappingURL=logger.d.ts.map