import type { YAMLNode, LoadOptions } from 'yaml-ast-parser';
import type { NormalizedNodeType } from './types/index.js';
import type { ResolveConfig } from './config/types.js';
export type CollectedRefs = Map<string, Document>;
export declare class Source {
    absoluteRef: string;
    body: string;
    mimeType?: string | undefined;
    constructor(absoluteRef: string, body: string, mimeType?: string | undefined);
    private _ast;
    private _lines;
    getAst(safeLoad: (input: string, options?: LoadOptions | undefined) => YAMLNode): YAMLNode;
    getLines(): string[];
}
export declare class ResolveError extends Error {
    originalError: Error;
    constructor(originalError: Error);
}
export declare class YamlParseError extends Error {
    originalError: Error;
    source: Source;
    col: number;
    line: number;
    constructor(originalError: Error, source: Source);
}
export type Document<T = any> = {
    source: Source;
    parsed: T;
};
export declare function makeRefId(absoluteRef: string, pointer: string): string;
export declare function makeDocumentFromString<T = any>(sourceString: string, absoluteRef: string): Document<T>;
export declare class BaseResolver {
    protected config: ResolveConfig;
    cache: Map<string, Promise<Document | ResolveError>>;
    constructor(config?: ResolveConfig);
    getFiles(): Set<string>;
    resolveExternalRef(base: string | null, ref: string): string;
    loadExternalRef(absoluteRef: string): Promise<Source>;
    parseDocument(source: Source, isRoot?: boolean): Document;
    resolveDocument<T = any>(base: string | null, ref: string, isRoot?: boolean): Promise<Document<T> | ResolveError | YamlParseError>;
}
export type ResolvedRef = {
    resolved: false;
    isRemote: boolean;
    nodePointer?: string;
    document?: Document;
    source?: Source;
    error?: ResolveError | YamlParseError;
    node?: any;
} | {
    resolved: true;
    node: any;
    document: Document;
    nodePointer: string;
    isRemote: boolean;
    error?: undefined;
};
export type ResolvedRefMap = Map<string, ResolvedRef>;
export declare function resolveDocument(opts: {
    rootDocument: Document;
    externalRefResolver: BaseResolver;
    rootType: NormalizedNodeType;
}): Promise<ResolvedRefMap>;
//# sourceMappingURL=resolve.d.ts.map