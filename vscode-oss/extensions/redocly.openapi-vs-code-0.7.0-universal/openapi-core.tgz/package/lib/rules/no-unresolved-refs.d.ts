import type { Oas3Rule } from '../visitors.js';
import type { ResolveResult, Problem } from '../walk.js';
import type { Location } from '../ref-utils.js';
export declare const NoUnresolvedRefs: Oas3Rule;
export declare function reportUnresolvedRef(resolved: ResolveResult<any>, report: (m: Problem) => void, location: Location): void;
//# sourceMappingURL=no-unresolved-refs.d.ts.map