import type { Oas3Rule, Oas2Rule } from '../../visitors.js';
export declare const InfoLicenseUrl: Oas3Rule | Oas2Rule;
//# sourceMappingURL=info-license-url.d.ts.map