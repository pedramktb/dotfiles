import type { Oas2Rule, Oas3Rule } from '../../visitors.js';
export declare const PathExcludesPatterns: Oas3Rule | Oas2Rule;
//# sourceMappingURL=path-excludes-patterns.d.ts.map