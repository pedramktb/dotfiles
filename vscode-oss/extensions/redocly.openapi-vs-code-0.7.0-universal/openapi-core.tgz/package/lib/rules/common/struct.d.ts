import type { Oas3Rule, Oas2Rule, Async2Rule, Async3Rule, Arazzo1Rule, Overlay1Rule } from '../../visitors.js';
export declare const Struct: Oas3Rule | Oas2Rule | Async2Rule | Async3Rule | Arazzo1Rule | Overlay1Rule;
//# sourceMappingURL=struct.d.ts.map