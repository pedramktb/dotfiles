import type { Oas2Rule, Oas3Rule } from '../../visitors.js';
export declare const NoRequiredSchemaPropertiesUndefined: Oas3Rule | Oas2Rule;
//# sourceMappingURL=no-required-schema-properties-undefined.d.ts.map