import type { Oas3Rule, Oas2Rule } from '../../visitors.js';
export declare const NoEnumTypeMismatch: Oas3Rule | Oas2Rule;
//# sourceMappingURL=no-enum-type-mismatch.d.ts.map