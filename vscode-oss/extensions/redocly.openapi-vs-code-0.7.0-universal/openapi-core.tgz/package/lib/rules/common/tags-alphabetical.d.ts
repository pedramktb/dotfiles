import type { Oas3Rule, Oas2Rule } from '../../visitors.js';
export declare const TagsAlphabetical: Oas3Rule | Oas2Rule;
//# sourceMappingURL=tags-alphabetical.d.ts.map