import type { AssertionContext, AssertResult, CustomFunction } from '../../../config/types.js';
import type { Location } from '../../../ref-utils.js';
export type AssertionFnContext = AssertionContext & {
    baseLocation: Location;
    rawValue?: any;
};
export type AssertionFn = (value: any, condition: any, ctx: AssertionFnContext) => AssertResult[];
export type Asserts = {
    pattern: AssertionFn;
    notPattern: AssertionFn;
    enum: AssertionFn;
    defined: AssertionFn;
    required: AssertionFn;
    disallowed: AssertionFn;
    nonEmpty: AssertionFn;
    minLength: AssertionFn;
    maxLength: AssertionFn;
    casing: AssertionFn;
    sortOrder: AssertionFn;
    mutuallyExclusive: AssertionFn;
    mutuallyRequired: AssertionFn;
    requireAny: AssertionFn;
    ref: AssertionFn;
    const: AssertionFn;
};
export declare const runOnKeysSet: Set<keyof Asserts>;
export declare const runOnValuesSet: Set<keyof Asserts>;
export declare const asserts: Asserts;
export declare function buildAssertCustomFunction(fn: CustomFunction): AssertionFn;
//# sourceMappingURL=asserts.d.ts.map