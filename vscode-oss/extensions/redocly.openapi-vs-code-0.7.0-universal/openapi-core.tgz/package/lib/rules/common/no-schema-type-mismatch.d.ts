import type { Oas2Rule, Oas3Rule } from '../../visitors.js';
export declare const NoSchemaTypeMismatch: Oas3Rule | Oas2Rule;
//# sourceMappingURL=no-schema-type-mismatch.d.ts.map