import type { Arazzo1Rule } from '../../visitors.js';
export declare const NoXSecuritySchemeNameInWorkflow: Arazzo1Rule;
//# sourceMappingURL=no-x-security-scheme-name-in-workflow.d.ts.map