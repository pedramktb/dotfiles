import type { Oas2Decorator } from '../../visitors.js';
export declare const decorators: {
    'operation-description-override': Oas2Decorator;
    'tag-description-override': Oas2Decorator;
    'info-description-override': Oas2Decorator;
    'info-override': Oas2Decorator;
    'remove-x-internal': Oas2Decorator;
    'filter-in': Oas2Decorator;
    'filter-out': Oas2Decorator;
};
//# sourceMappingURL=index.d.ts.map