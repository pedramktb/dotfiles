import type { Oas3Decorator } from '../../visitors.js';
export declare const decorators: {
    'operation-description-override': Oas3Decorator;
    'tag-description-override': Oas3Decorator;
    'info-description-override': Oas3Decorator;
    'info-override': Oas3Decorator;
    'remove-x-internal': Oas3Decorator;
    'filter-in': Oas3Decorator;
    'filter-out': Oas3Decorator;
    'media-type-examples-override': Oas3Decorator;
};
//# sourceMappingURL=index.d.ts.map